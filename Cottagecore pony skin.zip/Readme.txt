Hello!

Thank you very much for using my application <3

To install the skin:
- Close the "Boop the Pony" application
- Open the application folder
- Open the Assets folder
- Copy the 1_Cottagecore pony folder inside the Assets folder
- Launch the app!

To change the skin, access the in application menu by clicking on the cutiemark icon. 
Select a skin by clicking on the arrows!

In case of doubt, check the visual installation guide